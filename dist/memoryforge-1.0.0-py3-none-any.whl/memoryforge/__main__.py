"""Entry point for running MemoryForge as a module."""

from memoryforge.cli import main

if __name__ == "__main__":
    main()
