"""Tests for the storage layer."""
